import Phaser from 'phaser'
import type { UiLayout } from './ResponsiveLayout'
import { getTier } from '../config/ballTiers'
import { ballLookFor, ballOutlineWidth, drawBallFace, restContour, INK, drawRainbowBall, drawFantasyBall } from '../game/rendering/BallAppearance'
import { variantIdFor } from '../game/state/runVariant'
import { hudText, WHITE } from './Typography'

/**
 * Phase 2.11.0 next-ball preview (spec §5, §11): draws the UPCOMING ball
 * through the SHARED `BallAppearance` pipeline — the same tier color, the
 * same seed, the same functions the gameplay renderer and the crane use.
 * Not a texture, not a generic circle: the actual character that will drop.
 */
export class NextBall {
  private g: Phaser.GameObjects.Graphics | null = null
  private label: Phaser.GameObjects.Text | null = null
  private tier = 1
  private seed = 1
  private pos: { x: number; y: number } = { x: 0, y: 0 }
  private diameter = 56
  private readonly scene: Phaser.Scene

  constructor(scene: Phaser.Scene) {
    this.scene = scene
  }

  /** QA hook: preview ball center + diameter (viewport px). */
  center(): { x: number; y: number; diameter: number } {
    return { x: this.pos.x, y: this.pos.y, diameter: this.diameter }
  }

  setNext(tier: number, seed: number): void {
    if (this.tier === tier && this.seed === seed) return
    this.tier = tier
    this.seed = seed
    this.redraw()
  }

  layout(l: UiLayout): void {
    this.pos = { x: l.nextBall.pos.x, y: l.nextBall.pos.y }
    this.diameter = l.nextBall.diameter
    this.g?.destroy()
    this.label?.destroy()
    this.g = this.scene.add.graphics().setDepth(42)
    this.label = hudText(this.scene, l.nextBall.label.x, l.nextBall.label.y, 'Next Ball:', l.fontScale, {
      color: WHITE,
      size: 22,
      stroke: 3,
      origin: [0.5, 0],
    })
    this.redraw()
  }

  /** Draw the character centered at the configured position. */
  private redraw(): void {
    const g = this.g
    if (!g) return
    g.clear()
    const tier = getTier(this.tier)
    if (!tier || !this.label) return
    const r = this.diameter / 2
    const look = ballLookFor(this.tier, this.seed)
    const poly = restContour(look, r, this.pos.x, this.pos.y, 40)
    
    // Phase 2.12.1: Special rendering for Tier 8/9 in preview.
    // Phase 2.14.0: per-run variant (tiers 8-9 randomize each run).
    if (this.tier === 8) {
      const pts = poly.map(p => ({ x: p.x, y: p.y }))
      drawRainbowBall(g, pts, this.pos.x, this.pos.y, r, Date.now(), variantIdFor(8))
    } else if (this.tier === 9) {
      drawFantasyBall(g, this.pos.x, this.pos.y, r, variantIdFor(9))
    } else {
      g.fillStyle(tier.color, 1)
      g.fillPoints(poly.map((p) => new Phaser.Math.Vector2(p.x, p.y)), true)
    }
    
    g.lineStyle(ballOutlineWidth(r), INK, 1)
    g.strokePoints(poly.map((p) => new Phaser.Math.Vector2(p.x, p.y)), true, true)
    drawBallFace(g, look, { x: this.pos.x, y: this.pos.y }, r, 1)
  }
}
