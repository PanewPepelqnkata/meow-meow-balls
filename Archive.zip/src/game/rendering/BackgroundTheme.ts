import Phaser from 'phaser'

/**
 * Phase 2.13.0 (spec §6) — ILLUSTRATED background themes.
 *
 * Each theme is a real drawn environment, not a flat fill:
 * - light:   warm cream + soft corner blobs + the blue-gray grid (spec colors)
 * - space:   navy→purple gradient, nebula clouds, glowing regions, star field
 *            with glints, grid at restrained opacity
 * - jungle:  sky gradient, two mountain ranges, palm/leaf fronds framing the
 *            edges, a distant waterfall, cool green atmosphere
 * - fantasy: purple/blue twilight, glowing moon, ruined columns and arch
 *            silhouettes in depth layers, edge foliage
 *
 * All art is deterministic (seeded RNG per theme) so the per-frame redraws
 * during the 600–1000ms crossfade never flicker or jump. The crossfade draws
 * both environments with complementary alphas — the viewport stays covered at
 * every pixel throughout. Everything renders in the never-zoomed
 * BackgroundScene camera (screen space, scrollFactor 0).
 */

export type ThemeName = 'light' | 'space' | 'jungle' | 'fantasy'

interface ThemeDef {
  name: ThemeName
  bgColor: number
  gridColor: number
  gridAlpha: number
  draw: (g: Phaser.GameObjects.Graphics, w: number, h: number, rng: () => number) => void
}

/** Deterministic RNG (mulberry32) — stable art across redraws. */
function seeded(seed: number): () => number {
  let a = seed >>> 0
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/**
 * Phase 2.13.2 (spec §2) — SOFT CLOUDS replace the ellipse haze.
 *
 * The old `softGlow` stacked 3 hard-edged ellipses at alpha steps — at any
 * size it read as a stretched elliptical halo (the "broken background
 * circles" defect). A canvas radial-gradient texture has a genuinely smooth
 * falloff (zero visible edge steps), and each CLOUD is composed of three
 * offset gradient blobs at varied scales/orientations — an irregular soft
 * cloud shape, never an obvious centered circle.
 */
const CLOUD_TEX_KEY = 'br-softcloud'

/** Create (once) the shared radial-gradient soft-blob texture. */
function ensureCloudTexture(scene: Phaser.Scene): void {
  if (scene.textures.exists(CLOUD_TEX_KEY)) return
  const size = 256
  const tex = scene.textures.createCanvas(CLOUD_TEX_KEY, size, size)
  if (!tex) return
  const ctx = tex.getContext()
  const grad = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2)
  grad.addColorStop(0, 'rgba(255,255,255,1)')
  grad.addColorStop(0.32, 'rgba(255,255,255,0.6)')
  grad.addColorStop(0.62, 'rgba(255,255,255,0.22)')
  grad.addColorStop(1, 'rgba(255,255,255,0)')
  ctx.fillStyle = grad
  ctx.fillRect(0, 0, size, size)
  tex.refresh()
}

/** Cloud layer entries: tinted gradient images (+ fantasy's moon disc). */
type CloudObj = Phaser.GameObjects.Image | Phaser.GameObjects.Graphics

/**
 * Add ONE irregular soft cloud: three overlapping radial-gradient blobs with
 * varied scales and offsets (deterministic caller positions). `rw`/`rh` are
 * the main blob's radii; the two offset blobs break every hint of circular
 * symmetry.
 */
function addCloud(
  scene: Phaser.Scene,
  out: CloudObj[],
  cx: number,
  cy: number,
  rw: number,
  rh: number,
  tint: number,
  alpha: number,
): void {
  ensureCloudTexture(scene)
  const blob = (x: number, y: number, bw: number, bh: number, a: number) => {
    const img = scene.add
      .image(x, y, CLOUD_TEX_KEY)
      .setDepth(-98)
      .setScrollFactor(0)
      .setTint(tint)
      .setData('baseAlpha', a)
    img.setScale(bw / 256, bh / 256)
    // Parallax drift (px/s): bigger blobs sit "closer" and move faster.
    img.setData('drift', 2 + img.scaleX * 6)
    out.push(img)
  }
  blob(cx, cy, rw * 2, rh * 2, alpha * 0.6)
  blob(cx + rw * 0.5, cy - rh * 0.3, rw * 1.3, rh * 1.15, alpha * 0.45)
  blob(cx - rw * 0.45, cy + rh * 0.35, rw * 1.1, rh * 1.3, alpha * 0.4)
}

/** One pointed palm frond: a curved spine with tapered leaflets. */
function palmFrond(
  g: Phaser.GameObjects.Graphics,
  x: number,
  y: number,
  len: number,
  angle: number,
  color: number,
  outline: number,
): void {
  const leaflets = 9
  g.save()
  g.translateCanvas(x, y)
  g.rotateCanvas(angle)
  // Spine: sample a quadratic curve (Graphics has no quadraticCurveTo).
  g.lineStyle(4, outline, 1)
  g.beginPath()
  g.moveTo(0, 0)
  for (let s = 1; s <= 8; s++) {
    const t = s / 8
    g.lineTo(len * t, -Math.sin(t * Math.PI) * len * 0.14)
  }
  g.strokePath()
  for (let i = 1; i <= leaflets; i++) {
    const t = i / (leaflets + 1)
    const bx = len * t
    const by = -Math.sin(t * Math.PI) * len * 0.14
    const ll = len * 0.2 * (1 - Math.abs(t - 0.5))
    g.fillStyle(color, 1)
    g.beginPath()
    g.moveTo(bx, by)
    g.lineTo(bx + ll * 0.35, by - ll)
    g.lineTo(bx + ll * 0.7, by - ll * 0.15)
    g.closePath()
    g.fillPath()
    g.beginPath()
    g.moveTo(bx, by)
    g.lineTo(bx + ll * 0.35, by + ll * 0.85)
    g.lineTo(bx + ll * 0.7, by + ll * 0.1)
    g.closePath()
    g.fillPath()
  }
  g.restore()
}

/** Rounded bush silhouette cluster. */
function bushCluster(
  g: Phaser.GameObjects.Graphics,
  x: number,
  y: number,
  r: number,
  color: number,
  rng: () => number,
): void {
  for (let i = 0; i < 5; i++) {
    const bx = x + (rng() - 0.5) * r * 2.2
    const by = y - rng() * r * 0.6
    g.fillStyle(color, 1)
    g.fillCircle(bx, by, r * (0.45 + rng() * 0.5))
  }
}

/**
 * Phase 2.13.1 jungle: a SMOOTH rolling hill silhouette — two layered sine
 * waves (fixed frequencies, deterministic, no jagged randomness, no
 * triangular spikes). `phase` varies the shape per band.
 */
function rollingHill(
  g: Phaser.GameObjects.Graphics,
  w: number,
  h: number,
  baseY: number,
  amp: number,
  phase: number,
  color: number,
): void {
  g.fillStyle(color, 1)
  g.beginPath()
  g.moveTo(0, h)
  g.lineTo(0, baseY)
  for (let x = 0; x <= w; x += 8) {
    const y =
      baseY +
      Math.sin((x / w) * Math.PI * 2.2 + phase) * amp +
      Math.sin((x / w) * Math.PI * 5.3 + phase * 2.7) * amp * 0.35
    g.lineTo(x, y)
  }
  g.lineTo(w, h)
  g.closePath()
  g.fillPath()
}

/**
 * Phase 2.13.1 jungle: a scalloped leaf canopy band hanging from the top
 * edge — a chain of downward semicircle bumps of gently varying size, filled
 * solid. Reads as layered leaves, not geometric shapes.
 */
function canopyBand(
  g: Phaser.GameObjects.Graphics,
  w: number,
  depth: number,
  r: number,
  color: number,
  rng: () => number,
): void {
  g.fillStyle(color, 1)
  g.beginPath()
  g.moveTo(0, 0)
  g.lineTo(0, depth)
  let x = 0
  while (x < w) {
    const rr = r * (0.8 + rng() * 0.45)
    g.arc(x + rr, depth, rr, Math.PI, 0, true)
    x += rr * 1.75
  }
  g.lineTo(w, depth)
  g.lineTo(w, 0)
  g.closePath()
  g.fillPath()
}

/**
 * Phase 2.13.1 jungle: a hanging vine with small leaf pairs — a gentle
 * S-curve stroke plus paired leaf triangles.
 */
function vine(
  g: Phaser.GameObjects.Graphics,
  x: number,
  y0: number,
  len: number,
  color: number,
  outline: number,
): void {
  g.lineStyle(3, outline, 1)
  g.beginPath()
  g.moveTo(x, y0)
  g.lineTo(x + 5, y0 + len * 0.35)
  g.lineTo(x - 4, y0 + len * 0.7)
  g.lineTo(x + 2, y0 + len)
  g.strokePath()
  for (let i = 1; i <= 3; i++) {
    const t = i / 3.5
    const ly = y0 + len * t
    const lx = x + Math.sin(t * 5) * 4
    const ll = 7 * (1 - t * 0.4)
    for (const s of [-1, 1]) {
      g.fillStyle(color, 1)
      g.beginPath()
      g.moveTo(lx, ly)
      g.lineTo(lx + s * ll, ly - ll * 0.35)
      g.lineTo(lx + s * ll * 0.5, ly + ll * 0.3)
      g.closePath()
      g.fillPath()
    }
  }
}

/**
 * Phase 2.13.1 jungle: a rounded tree line along a baseline — small
 * trunked canopy trees, densely packed, for forest depth.
 */
function treeLine(g: Phaser.GameObjects.Graphics, w: number, y: number, color: number, rng: () => number): void {
  g.fillStyle(color, 1)
  let x = -12
  while (x < w + 12) {
    const tr = 13 + rng() * 15
    g.fillRect(x - 2.5, y - tr * 0.7, 5, tr * 0.7 + 8)
    g.fillCircle(x, y - tr, tr)
    g.fillCircle(x - tr * 0.75, y - tr * 0.55, tr * 0.7)
    g.fillCircle(x + tr * 0.75, y - tr * 0.55, tr * 0.7)
    x += tr * 1.45
  }
  // Ground the tree line with a soft base band.
  g.fillRect(0, y, w, 8)
}

/**
 * Phase 2.13.1 jungle: a leafy foreground mound — overlapping downward
 * scallop bumps along a baseline with a grounding base, far more organic
 * than the old circle-cluster bushes.
 */
function leafyMound(g: Phaser.GameObjects.Graphics, x: number, y: number, mw: number, mh: number, color: number): void {
  g.fillStyle(color, 1)
  const bumps = 4
  const step = mw / bumps
  for (let i = 0; i < bumps; i++) {
    const bx = x - mw / 2 + step * (i + 0.5)
    const br = step * 0.62
    g.beginPath()
    g.arc(bx, y - mh * 0.35, br, Math.PI, 0, true)
    g.closePath()
    g.fillPath()
  }
  g.fillRect(x - mw / 2 + step * 0.2, y - mh * 0.35, mw - step * 0.4, mh * 0.35 + 2)
}

/** A ruined column: base + shaft + broken top. */
function ruinedColumn(
  g: Phaser.GameObjects.Graphics,
  x: number,
  baseY: number,
  w: number,
  h: number,
  color: number,
): void {
  g.fillStyle(color, 1)
  g.fillRect(x - w * 0.72, baseY - h * 0.1, w * 1.44, h * 0.1) // base
  g.fillRect(x - w * 0.5, baseY - h, w, h * 0.92) // shaft
  g.fillRect(x - w * 0.66, baseY - h * 1.1, w * 0.5, h * 0.12) // broken lip
}

const THEMES: Record<ThemeName, ThemeDef> = {
  light: {
    name: 'light',
    bgColor: 0xf3f1eb, // Warm cream (spec §3 base)
    gridColor: 0xd7dce0, // Blue-gray grid (spec §3)
    gridAlpha: 0.8,
    // Phase 2.13.2: the corner haze moved to soft cloud images (see
    // BackgroundTheme.buildCloudGroup) — no hard-edged ellipse layers here.
    draw: () => {},
  },

  space: {
    name: 'space',
    bgColor: 0x0a1628, // Deep navy
    gridColor: 0x46597a,
    gridAlpha: 0.22,
    draw: (g, w, h, rng) => {
      // Vertical navy→purple depth gradient.
      g.fillGradientStyle(0x0a1628, 0x0a1628, 0x251543, 0x251543, 1)
      g.fillRect(0, 0, w, h)

      // Phase 2.13.2: the nebula clouds are soft IRREGULAR gradient-blob
      // clouds (see BackgroundTheme.buildCloudGroup) — no layered ellipse
      // haze here.

      // Star field: three depth sizes, a few with four-point glints.
      const stars = 90
      for (let i = 0; i < stars; i++) {
        const sx = rng() * w
        const sy = rng() * h
        const s = rng()
        const r = s < 0.75 ? 1 + rng() : s < 0.95 ? 2 + rng() * 0.8 : 2.6 + rng()
        const a = 0.35 + rng() * 0.6
        g.fillStyle(0xffffff, a)
        g.fillCircle(sx, sy, r)
        if (r > 2.4) {
          g.lineStyle(1.4, 0xffffff, a * 0.8)
          g.lineBetween(sx - r * 2.6, sy, sx + r * 2.6, sy)
          g.lineBetween(sx, sy - r * 2.6, sx, sy + r * 2.6)
        }
      }
    },
  },

  jungle: {
    name: 'jungle',
    bgColor: 0x9fd8b4, // Daylight canopy sky
    gridColor: 0x3f6f52,
    gridAlpha: 0.16,
    draw: (g, w, h, rng) => {
      // Phase 2.13.1 (spec §6) — a COHESIVE illustrated jungle:
      // smooth layered hills (no jagged triangles), a soft waterfall with
      // mist, a scalloped leaf canopy framing the top with hanging vines,
      // palm fronds at the corners, and leafy mounds (not circle clusters)
      // at the bottom. The central play area stays clear. All art is
      // deterministic (seeded) so crossfade redraws never flicker.

      // Sky: pale green-teal fading into forest haze.
      g.fillGradientStyle(0xbfe8c8, 0xbfe8c8, 0x7cc29a, 0x7cc29a, 1)
      g.fillRect(0, 0, w, h)

      // Distant hills: SMOOTH rolling silhouettes (layered sines — no
      // random jagged polyline, no triangular spikes).
      rollingHill(g, w, h, h * 0.58, h * 0.05, 0.9, 0x74b28a)
      rollingHill(g, w, h, h * 0.7, h * 0.06, 3.1, 0x4f8f68)

      // Waterfall: a tapered white ribbon falling from the mid hill notch,
      // with a bright streak, a pool at the base and soft mist puffs.
      const wx = w * 0.74
      const wy = h * 0.62
      const fh = h * 0.17
      g.fillStyle(0xe4f6ec, 0.85)
      g.beginPath()
      g.moveTo(wx - w * 0.012, wy)
      g.lineTo(wx + w * 0.012, wy)
      g.lineTo(wx + w * 0.02, wy + fh)
      g.lineTo(wx - w * 0.02, wy + fh)
      g.closePath()
      g.fillPath()
      g.fillStyle(0xffffff, 0.55)
      g.fillRect(wx - w * 0.004, wy, w * 0.008, fh)
      g.fillStyle(0xd0efe2, 0.85)
      g.fillEllipse(wx, wy + fh, w * 0.085, h * 0.022)
      // Phase 2.13.2: the waterfall mist puff is a soft cloud image (see
      // BackgroundTheme.buildCloudGroup).

      // Forest depth: a rounded tree line at the base of the hills.
      treeLine(g, w, h * 0.88, 0x3a7350, rng)

      // Top canopy: two scalloped leaf bands (dark outer, brighter inner)
      // with a few hanging vines.
      const ink = 0x1c3d28
      canopyBand(g, w, h * 0.075, Math.min(w, h) * 0.055, 0x2f6b44, rng)
      canopyBand(g, w, h * 0.045, Math.min(w, h) * 0.04, 0x47925c, rng)
      for (let i = 0; i < 4; i++) {
        vine(g, w * (0.16 + i * 0.23 + rng() * 0.05), h * 0.07, h * (0.06 + rng() * 0.05), 0x3d8556, ink)
      }

      // Framing palm fronds: top corners and lower sides.
      const frondLen = Math.min(w, h) * 0.3
      const dark = 0x2f6b44
      const mid = 0x4d9b62
      palmFrond(g, -w * 0.02, h * 0.05, frondLen, 0.55, dark, ink)
      palmFrond(g, -w * 0.02, h * 0.015, frondLen * 0.78, 0.9, mid, ink)
      palmFrond(g, w * 1.02, h * 0.07, frondLen, Math.PI - 0.55, dark, ink)
      palmFrond(g, w * 1.02, h * 0.03, frondLen * 0.82, Math.PI - 0.9, mid, ink)
      palmFrond(g, -w * 0.02, h * 0.93, frondLen * 0.8, -0.5, dark, ink)
      palmFrond(g, w * 1.02, h * 0.95, frondLen * 0.8, Math.PI + 0.5, dark, ink)

      // Foreground leafy mounds at the bottom corners (scalloped silhouettes
      // — no oversized circle clusters).
      leafyMound(g, w * 0.07, h * 1.0, Math.min(w, h) * 0.26, Math.min(w, h) * 0.11, 0x35754a)
      leafyMound(g, w * 0.93, h * 1.0, Math.min(w, h) * 0.26, Math.min(w, h) * 0.11, 0x35754a)
    },
  },

  fantasy: {
    name: 'fantasy',
    bgColor: 0x2a1f4d, // Purple twilight
    gridColor: 0x6f5b94,
    gridAlpha: 0.18,
    draw: (g, w, h, rng) => {
      // Twilight gradient: indigo sky → violet horizon.
      g.fillGradientStyle(0x1d1740, 0x1d1740, 0x4a2e6e, 0x4a2e6e, 1)
      g.fillRect(0, 0, w, h)

      // Phase 2.13.2: the moon, its soft halo and the horizon glow are cloud
      // layer objects (see BackgroundTheme.buildCloudGroup) — the moon disc
      // draws ABOVE its halo so it stays crisp.

      // Stars.
      for (let i = 0; i < 60; i++) {
        const sx = rng() * w
        const sy = rng() * h * 0.6
        g.fillStyle(0xffffff, 0.25 + rng() * 0.5)
        g.fillCircle(sx, sy, 0.8 + rng() * 1.4)
      }

      // Far ruins layer (silhouette, atmospheric).
      const far = 0x3a2a63
      for (let i = 0; i < 4; i++) {
        const cx = w * (0.12 + i * 0.24 + rng() * 0.06)
        const ch = h * (0.16 + rng() * 0.12)
        ruinedColumn(g, cx, h * 0.72, w * 0.02, ch, far)
      }
      g.fillStyle(far, 1)
      g.fillRect(0, h * 0.72, w, h * 0.28)

      // Broken arch mid-layer.
      const mid = 0x2c204e
      const ax = w * 0.3
      const ay = h * 0.78
      g.lineStyle(w * 0.02, mid, 1)
      g.beginPath()
      g.arc(ax, ay, Math.min(w, h) * 0.16, Math.PI, Math.PI * 1.75)
      g.strokePath()
      g.fillStyle(mid, 1)
      g.fillRect(ax - Math.min(w, h) * 0.17, ay - h * 0.02, w * 0.024, h * 0.1)
      g.fillRect(ax + Math.min(w, h) * 0.148, ay - Math.min(w, h) * 0.152, w * 0.024, h * 0.09)

      // Near columns (larger, darker, framing).
      const near = 0x201640
      ruinedColumn(g, w * 0.06, h * 0.94, w * 0.035, h * 0.3, near)
      ruinedColumn(g, w * 0.94, h * 0.96, w * 0.035, h * 0.26, near)

      // Edge foliage.
      bushCluster(g, w * 0.03, h * 0.98, Math.min(w, h) * 0.08, 0x274d3d, rng)
      bushCluster(g, w * 0.97, h * 1.0, Math.min(w, h) * 0.08, 0x274d3d, rng)
      palmFrond(g, w * 1.01, h * 0.2, Math.min(w, h) * 0.26, Math.PI - 0.7, 0x274d3d, 0x14251d)
    },
  },
}

/**
 * Manages illustrated background themes with smooth crossfades.
 */
export class BackgroundTheme {
  private scene: Phaser.Scene
  private currentTheme: ThemeName = 'light'
  private bgLayer!: Phaser.GameObjects.Graphics
  private gridLayer!: Phaser.GameObjects.Graphics
  private starLayer?: Phaser.GameObjects.Graphics
  private transitionTween?: Phaser.Tweens.Tween
  private transitionProgress = 0
  private fromTheme: ThemeName | null = null
  private toTheme: ThemeName | null = null
  private stars: Array<{ x: number; y: number; size: number; twinkle: number; glint: boolean }> = []
  private starAlpha = 0
  /** Phase 2.13.2: per-theme soft cloud layers (irregular gradient blobs). */
  private cloudGroups: Partial<Record<ThemeName, CloudObj[]>> = {}

  constructor(scene: Phaser.Scene) {
    this.scene = scene
    // CRITICAL: Background must render in screen space, not world space.
    // setScrollFactor(0) makes these graphics ignore camera zoom/pan.
    this.bgLayer = scene.add.graphics().setDepth(-100).setScrollFactor(0)
    this.gridLayer = scene.add.graphics().setDepth(-90).setScrollFactor(0)
    this.starLayer = scene.add.graphics().setDepth(-95).setScrollFactor(0)

    this.drawBackground()
    this.drawGrid()
    this.initStars('light')
    this.buildCloudGroup('light')
    this.applyCloudAlphas()

    scene.scale.on(Phaser.Scale.Events.RESIZE, this.handleResize, this)
    scene.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      scene.scale.off(Phaser.Scale.Events.RESIZE, this.handleResize, this)
    })
  }

  /** Phase 2.13.0: the settled theme name (mid-transition reports the target). */
  get themeName(): ThemeName {
    return this.toTheme ?? this.currentTheme
  }

  private handleResize(): void {
    this.drawBackground()
    this.drawGrid()
    this.initStars(this.currentTheme)
    this.rebuildClouds()
  }

  /**
   * Change to a new theme with a smooth crossfade (both environments drawn
   * with complementary alphas — the viewport stays covered at every pixel).
   */
  setTheme(theme: ThemeName, duration = 800): void {
    if (theme === this.currentTheme && !this.transitionTween) return
    if (theme === this.toTheme) return

    this.fromTheme = this.currentTheme
    this.toTheme = theme
    this.transitionProgress = 0
    this.initStars(theme)
    // Both cloud layers exist for the whole crossfade; their group alphas
    // track the transition (applyCloudAlphas).
    this.buildCloudGroup(this.fromTheme)
    this.buildCloudGroup(theme)
    this.applyCloudAlphas()

    this.transitionTween?.stop()
    this.transitionTween = this.scene.tweens.add({
      targets: this,
      transitionProgress: 1,
      duration,
      ease: 'Sine.easeInOut',
      onUpdate: () => {
        this.drawBackground()
        this.drawGrid()
      },
      onComplete: () => {
        this.currentTheme = theme
        this.fromTheme = null
        this.toTheme = null
        this.transitionProgress = 0
        this.transitionTween = undefined
        this.drawBackground()
        this.drawGrid()
      },
    })
  }

  /** Stable star field for the space theme (deterministic layout). */
  private initStars(theme: ThemeName): void {
    const { width, height } = this.scene.scale
    // Deliberately NOT the space theme's draw seed (20260213): the twinkle
    // layer must not land exactly on top of the baked static stars.
    const rng = seeded(20260215)
    this.stars = []
    if (theme === 'space') {
      for (let i = 0; i < 90; i++) {
        const s = rng()
        this.stars.push({
          x: rng() * width,
          y: rng() * height,
          size: 1 + rng() * 2,
          twinkle: rng() * Math.PI * 2,
          glint: s > 0.94,
        })
      }
    }
  }

  /**
   * Phase 2.13.2 (spec §2): build a theme's soft cloud layer — IRREGULAR
   * clouds (three offset radial-gradient blobs each), replacing every
   * hard-edged ellipse haze. Positions are deterministic (seeded per theme)
   * so crossfades and resize rebuilds are stable. Fantasy's moon disc lives
   * here too, ABOVE its halo cloud, so it stays crisp.
   */
  private buildCloudGroup(theme: ThemeName): void {
    this.destroyCloudGroup(theme)
    const { width: w, height: h } = this.scene.scale
    const m = Math.min(w, h)
    const group: CloudObj[] = []
    const rng = seeded(theme === 'light' ? 20260241 : theme === 'space' ? 20260242 : theme === 'jungle' ? 20260243 : 20260244)

    if (theme === 'light') {
      // Gentle warm-white clouds keep the cream field from feeling flat.
      addCloud(this.scene, group, w * 0.16, h * 0.14, m * 0.16, m * 0.085, 0xffffff, 0.5)
      addCloud(this.scene, group, w * 0.82, h * 0.24, m * 0.13, m * 0.07, 0xf0f6f7, 0.42)
      addCloud(this.scene, group, w * 0.62, h * 0.9, m * 0.17, m * 0.08, 0xffffff, 0.3)
    } else if (theme === 'space') {
      // Nebula clouds: irregular, tinted, subtle — never radial halos.
      const cols = [0x5b3fa8, 0x2c4f9e, 0x8a4b8f, 0x3d6bb0, 0x6b3fa8]
      for (let i = 0; i < 5; i++) {
        const nx = w * (0.15 + rng() * 0.7)
        const ny = h * (0.12 + rng() * 0.7)
        const nr = m * (0.11 + rng() * 0.13)
        addCloud(this.scene, group, nx, ny, nr, nr * 0.62, cols[i % cols.length]!, 0.34)
      }
      // Soft region low behind the container.
      addCloud(this.scene, group, w * 0.5, h * 0.74, m * 0.26, m * 0.13, 0x3d5fb0, 0.22)
    } else if (theme === 'jungle') {
      // Waterfall mist puffs at the pool (matches draw(): wx=0.74w, pool at
      // wy+fh = 0.62h + 0.17h).
      addCloud(this.scene, group, w * 0.74, h * 0.81, m * 0.05, m * 0.02, 0xffffff, 0.4)
      addCloud(this.scene, group, w * 0.74, h * 0.785, m * 0.035, m * 0.016, 0xffffff, 0.3)
      // Faint humid haze drifting in the sky.
      addCloud(this.scene, group, w * 0.3, h * 0.22, m * 0.14, m * 0.05, 0xdff2e4, 0.16)
    } else {
      // fantasy: soft moon halo + horizon glow clouds, plus the crisp moon
      // disc drawn ABOVE the halo (depth -97, one step above the clouds).
      addCloud(this.scene, group, w * 0.78, h * 0.16, m * 0.14, m * 0.09, 0xcfd8ff, 0.42)
      addCloud(this.scene, group, w * 0.5, h * 0.7, m * 0.3, m * 0.15, 0x7a5fb0, 0.2)
      const moon = this.scene.add.graphics().setDepth(-97).setScrollFactor(0)
      moon.fillStyle(0xe8ecff, 1)
      moon.fillCircle(w * 0.78, h * 0.16, m * 0.07)
      moon.setData('baseAlpha', 1)
      group.push(moon)
    }

    this.cloudGroups[theme] = group
  }

  private destroyCloudGroup(theme: ThemeName): void {
    const group = this.cloudGroups[theme]
    if (!group) return
    for (const obj of group) obj.destroy()
    delete this.cloudGroups[theme]
  }

  /** Rebuild every LIVE cloud layer for the current viewport size. */
  private rebuildClouds(): void {
    const live: ThemeName[] = [this.currentTheme]
    if (this.fromTheme) live.push(this.fromTheme)
    if (this.toTheme) live.push(this.toTheme)
    for (const t of live) this.buildCloudGroup(t)
    this.applyCloudAlphas()
  }

  /**
   * Drive cloud layer alphas alongside the Graphics crossfade: outside a
   * transition only the current theme's layer is visible; during a
   * transition the from/to layers fade complementarily.
   */
  private applyCloudAlphas(): void {
    for (const [name, group] of Object.entries(this.cloudGroups)) {
      if (!group) continue
      const themeName = name as ThemeName
      let a: number
      if (this.toTheme) {
        if (themeName === this.toTheme) a = this.transitionProgress
        else if (themeName === this.fromTheme) a = 1 - this.transitionProgress
        else a = 0
      } else {
        a = themeName === this.currentTheme ? 1 : 0
      }
      for (const obj of group) {
        const go = obj as CloudObj & { setAlpha(v: number): unknown; setVisible(v: boolean): unknown }
        go.setAlpha((obj.getData('baseAlpha') as number) * a)
        go.setVisible(a > 0.005)
      }
    }
  }

  private drawBackground(): void {
    const g = this.bgLayer
    g.clear()
    const { width, height } = this.scene.scale

    if (!this.fromTheme || !this.toTheme || this.transitionProgress <= 0) {
      const t = THEMES[this.currentTheme]
      g.fillStyle(t.bgColor, 1)
      g.fillRect(0, 0, width, height)
      t.draw(g, width, height, seeded(20260213))
      this.applyCloudAlphas()
      return
    }

    const t = this.transitionProgress
    const from = THEMES[this.fromTheme]
    const to = THEMES[this.toTheme]

    // Under-coat: the FROM base color (guarantees full coverage at t≈0).
    g.fillStyle(from.bgColor, 1)
    g.fillRect(0, 0, width, height)
    from.draw(g, width, height, seeded(20260213))

    // Crossfade curtain: TO base color + environment fading in on top.
    g.fillStyle(to.bgColor, t)
    g.fillRect(0, 0, width, height)
    to.draw(g, width, height, seeded(20260213 + 7))
    this.applyCloudAlphas()
  }

  private drawGrid(): void {
    const g = this.gridLayer
    g.clear()
    const { width, height } = this.scene.scale
    const cellSize = 42

    // Lerp the grid color/alpha across a crossfade instead of snapping —
    // otherwise the grid pops to the target theme on the transition's
    // first frame while the sky is still blending.
    let color: number
    let alpha: number
    if (this.fromTheme && this.toTheme && this.transitionProgress > 0) {
      const from = THEMES[this.fromTheme]
      const to = THEMES[this.toTheme]
      const t = this.transitionProgress
      const mixed = Phaser.Display.Color.Interpolate.ColorWithColor(
        Phaser.Display.Color.IntegerToColor(from.gridColor),
        Phaser.Display.Color.IntegerToColor(to.gridColor),
        100,
        t * 100,
      )
      color = mixed.color
      alpha = from.gridAlpha + (to.gridAlpha - from.gridAlpha) * t
    } else {
      const def = THEMES[this.currentTheme]
      color = def.gridColor
      alpha = def.gridAlpha
    }

    g.lineStyle(1, color, alpha)
    for (let x = 0; x <= width; x += cellSize) {
      g.beginPath()
      g.moveTo(x, 0)
      g.lineTo(x, height)
      g.strokePath()
    }
    for (let y = 0; y <= height; y += cellSize) {
      g.beginPath()
      g.moveTo(0, y)
      g.lineTo(width, y)
      g.strokePath()
    }
  }

  private drawStars(): void {
    if (!this.starLayer) return
    const g = this.starLayer
    g.clear()
    if (this.stars.length === 0 || this.starAlpha <= 0.01) return
    for (const star of this.stars) {
      const twinkleAlpha = 0.4 + 0.6 * Math.abs(Math.sin(star.twinkle + this.scene.time.now * 0.0012))
      g.fillStyle(0xffffff, this.starAlpha * twinkleAlpha)
      g.fillCircle(star.x, star.y, star.size)
      if (star.glint) {
        g.lineStyle(1.4, 0xffffff, this.starAlpha * twinkleAlpha * 0.8)
        const r = star.size * 2.6
        g.lineBetween(star.x - r, star.y, star.x + r, star.y)
        g.lineBetween(star.x, star.y - r, star.x, star.y + r)
      }
    }
  }

  /** Per-frame star twinkle + cloud drift (called from BackgroundScene.update). */
  update(delta: number): void {
    const fromSpace = this.currentTheme === 'space'
    const toSpace = this.toTheme === 'space'
    if (this.toTheme) {
      // During a transition, track the curtain alpha so stars never pop:
      // space → X fades out, X → space fades in, X → Y (neither space)
      // keeps stars invisible for the whole crossfade.
      this.starAlpha = fromSpace && toSpace ? 1 : fromSpace ? 1 - this.transitionProgress : toSpace ? this.transitionProgress : 0
    } else {
      this.starAlpha = fromSpace ? 1 : 0
    }
    this.drawStars()
    // Slow parallax drift on the cloud blobs (Images only — the fantasy
    // moon is a Graphics and stays put). Wrapped at the viewport edges.
    const w = this.scene.scale.width
    for (const group of Object.values(this.cloudGroups)) {
      if (!group) continue
      for (const obj of group) {
        const img = obj as Phaser.GameObjects.Image
        if (img.type !== 'Image') continue
        const drift = img.getData('drift') as number | undefined
        if (!drift) continue
        img.x += drift * (delta / 1000)
        if (img.x - img.displayWidth / 2 > w) img.x = -img.displayWidth / 2
      }
    }
  }

  destroy(): void {
    this.transitionTween?.stop()
    this.bgLayer?.destroy()
    this.gridLayer?.destroy()
    this.starLayer?.destroy()
    for (const name of Object.keys(this.cloudGroups) as ThemeName[]) this.destroyCloudGroup(name)
  }
}
