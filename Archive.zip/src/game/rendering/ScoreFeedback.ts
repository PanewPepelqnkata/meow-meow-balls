import Phaser from 'phaser'
import { gradeForChain } from '../../config/presentation'
import { getTier } from '../../config/ballTiers'

/**
 * Phase 2.13.0 (spec §8) — merge reward feedback driven by REAL game state.
 *
 * - The `+N` popup shows the actual points awarded, tinted with the merged
 *   tier's color (bold cartoon lettering, thick outline, offset shadow).
 * - The grade label and `Nx Combo!` derive from the REAL merge-chain depth
 *   passed by MergeSystem via the centralized `gradeForChain` mapping —
 *   never from score size, so an ordinary single merge can never show a top
 *   grade (the 2.12.0 defect: big single-tier merges displayed "Wild!").
 * - Concurrent popups stagger into separate lanes so overlapping merges
 *   stay readable and never stack on one pixel.
 */

const POPUP_DEPTH = 1000
const DURATION = 820

interface ScorePopup {
  container: Phaser.GameObjects.Container
  created: number
  duration: number
}

export class ScoreFeedback {
  private scene: Phaser.Scene
  private popups: ScorePopup[] = []
  /** Lane cycler: spreads simultaneous popups vertically. */
  private lane = 0
  /** Phase 2.13.0: live merge-burst objects (killed on restart). */
  private burstObjs: Array<Phaser.GameObjects.GameObject> = []

  constructor(scene: Phaser.Scene) {
    this.scene = scene
  }

  /** QA hook (Phase 2.12.1, read-only): live popup count. */
  get popupCount(): number {
    return this.popups.length
  }

  /** QA hook (Phase 2.12.1, read-only): text labels currently shown. */
  get popupLabels(): string[] {
    return this.popups.flatMap((p) =>
      (p.container?.list ?? [])
        .filter((o): o is Phaser.GameObjects.Text => o instanceof Phaser.GameObjects.Text)
        .map((t) => t.text),
    )
  }

  /** QA hook (Phase 2.12.1, read-only): alphas of live popups. */
  get popupAlphas(): number[] {
    return this.popups.map((p) => p.container?.alpha ?? 0)
  }

  /**
   * Show the reward for one completed merge.
   * @param chainDepth the REAL merge-chain depth from MergeSystem (≥1).
   * @param tier the merged-into tier (colors the `+N` text).
   */
  showScoreReward(points: number, x: number, y: number, showGrade = true, chainDepth = 1, tier = 2): void {
    // Cap: a pathological mega-chain must not stack dozens of containers
    // each running three tweens — the newest popups matter, drop extras.
    if (this.popups.length >= 10) return
    const depth = Math.max(1, chainDepth)
    // Stagger lanes so quick chains don't stack every label on one pixel.
    // Only apply the offset while older popups are still fading.
    const active = this.popups.filter((p) => this.scene.time.now - p.created < DURATION * 0.6)
    const laneOffset = active.length > 0 ? (this.lane++ % 3) : 0
    const px = x + (laneOffset === 2 ? 26 : laneOffset === 1 ? -26 : 0)
    const py = y - 20 - laneOffset * 44

    const container = this.scene.add.container(px, py).setDepth(POPUP_DEPTH)

    // `+N` in the merged tier's color — bold, outlined, offset shadow.
    const tierColor = getTier(tier)?.color ?? 0xffeb3b
    const scoreText = this.scene.add.text(0, 0, `+${points}`, {
      fontFamily: 'Lilita One, Arial Black, sans-serif',
      fontSize: `${44 + Math.min(20, depth * 4)}px`,
      color: '#' + tierColor.toString(16).padStart(6, '0'),
      stroke: '#000000',
      strokeThickness: 7,
    })
    scoreText.setOrigin(0.5)
    scoreText.setShadow(3, 3, '#000000', 0, true, true)
    container.add(scoreText)

    // Grade from the REAL chain state (centralized mapping, spec §8).
    if (showGrade) {
      const { grade, color } = gradeForChain(depth)
      const gradeText = this.scene.add.text(0, 42, grade, {
        fontFamily: 'Lilita One, Arial Black, sans-serif',
        fontSize: `${24 + Math.min(14, depth * 3)}px`,
        color,
        stroke: '#000000',
        strokeThickness: 5,
      })
      gradeText.setOrigin(0.5)
      gradeText.setShadow(2, 2, '#000000', 0, true, true)
      container.add(gradeText)

      if (depth >= 2) {
        const comboText = this.scene.add.text(0, 78, `${depth}x Combo!`, {
          fontFamily: 'Lilita One, Arial Black, sans-serif',
          fontSize: `${22 + Math.min(12, depth * 2)}px`,
          color: '#ffeb3b',
          stroke: '#000000',
          strokeThickness: 5,
        })
        comboText.setOrigin(0.5)
        comboText.setShadow(2, 2, '#000000', 0, true, true)
        container.add(comboText)
      }
    }

    // Punchy entrance → settle → float → fade (650–1000ms band).
    container.setScale(0.7)
    container.setAlpha(0)
    this.scene.tweens.add({
      targets: container,
      scale: 1.14,
      alpha: 1,
      duration: 140,
      ease: 'Back.easeOut',
      onComplete: () => {
        this.scene.tweens.add({ targets: container, scale: 1, duration: 90, ease: 'Sine.easeOut' })
      },
    })
    this.scene.tweens.add({
      targets: container,
      y: py - 54,
      duration: DURATION * 0.7,
      ease: 'Sine.easeOut',
    })
    this.scene.tweens.add({
      targets: container,
      alpha: 0,
      delay: DURATION * 0.58,
      duration: DURATION * 0.42,
      ease: 'Sine.easeIn',
      onComplete: () => {
        container.destroy()
        this.popups = this.popups.filter((p) => p.container !== container)
      },
    })

    this.popups.push({ container, created: this.scene.time.now, duration: DURATION })
  }

  /**
   * Phase 2.13.0 (spec §8): restrained burst at the ACTUAL merge location —
   * a brief impact ring plus tier-colored confetti/sparkles. Pure visual
   * objects (no physics bodies), bounded count, everything self-destroys.
   */
  showMergeBurst(x: number, y: number, tier: number): void {
    const tierColor = getTier(tier)?.color ?? 0xffeb3b
    const depth = this.scene.add.graphics().setDepth(999)

    // Impact ring: quick expand + fade (~300ms) — a plain tween on a proxy
    // (frame-rate independent, no 16ms polling timer).
    const ringStart = 18
    const ringEnd = 64
    const ring = { t: 0 }
    this.scene.tweens.add({
      targets: ring,
      t: 1,
      duration: 300,
      ease: 'Linear',
      onUpdate: () => {
        depth.clear()
        depth.lineStyle(3.5, tierColor, 0.85 * (1 - ring.t))
        depth.strokeCircle(x, y, ringStart + (ringEnd - ringStart) * ring.t)
        depth.lineStyle(2, 0xffffff, 0.5 * (1 - ring.t))
        depth.strokeCircle(x, y, (ringStart + (ringEnd - ringStart) * ring.t) * 0.7)
      },
      onComplete: () => depth.destroy(),
    })

    // Confetti: bounded 10 pieces, tier color + white + gold, outward drift
    // with a slight downward settle, all destroyed after ~650ms.
    const palette = [tierColor, 0xffffff, 0xffd54f]
    this.burstObjs = this.burstObjs.filter((o) => o.active)
    for (let i = 0; i < 10; i++) {
      const a = (Math.PI * 2 * i) / 10 + Math.random() * 0.4
      const dist = 30 + Math.random() * 44
      const size = 2.5 + Math.random() * 3
      const color = palette[i % palette.length]!
      const piece = this.scene.add.graphics().setDepth(999)
      piece.fillStyle(color, 1)
      piece.fillCircle(0, 0, size)
      piece.setPosition(x, y)
      this.burstObjs.push(piece)
      const dx = Math.cos(a) * dist
      const dy = Math.sin(a) * dist - 14
      this.scene.tweens.add({
        targets: piece,
        x: x + dx,
        y: y + dy + 26, // slight downward settle after the outward kick
        alpha: 0,
        duration: 480 + Math.random() * 200,
        ease: 'Cubic.easeOut',
        onComplete: () => {
          piece.destroy()
          this.burstObjs = this.burstObjs.filter((o) => o !== piece)
        },
      })
    }
  }

  /** Reset combo state (e.g., on game restart). */
  resetCombo(): void {
    this.lane = 0
  }

  /** Clear all active popups (e.g., on restart). */
  clearAll(): void {
    for (const popup of this.popups) {
      this.scene.tweens.killTweensOf(popup.container)
      popup.container.destroy()
    }
    this.popups = []
    // Phase 2.13.0: merge bursts die with the run (they are short-lived but
    // a restart must never leave confetti behind).
    for (const o of this.burstObjs) {
      this.scene.tweens.killTweensOf(o)
      o.destroy()
    }
    this.burstObjs = []
    this.resetCombo()
  }

  destroy(): void {
    this.clearAll()
  }
}
