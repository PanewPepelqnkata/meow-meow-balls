import Phaser from 'phaser'
import { hudText, FONT_FAMILY } from '../../ui/Typography'
import { CartoonButton, Icons } from '../../ui/CartoonButton'

/**
 * Phase 2.11.0 game-over overlay (spec §12): full-viewport cartoon overlay
 * in UIScene — dimmed backdrop, outlined "GAME OVER" heading in the display
 * font, the run's score + best, and a chunky illustrated PLAY AGAIN button
 * with the shared press animation. Behavior (show/hide/restart wiring) is
 * unchanged from 2.10.0.
 */
export class GameOverView {
  private objs: Phaser.GameObjects.GameObject[] = []
  /** The score count-up tween — stopped in hide() so it never pokes a
   * destroyed text. */
  private countTween: Phaser.Tweens.Tween | null = null
  /** Viewport-space center of the PLAY AGAIN button (QA hook). */
  private lastButtonCenter = { x: 0, y: 0 }
  private readonly scene: Phaser.Scene

  constructor(scene: Phaser.Scene) {
    this.scene = scene
  }

  get visible(): boolean {
    return this.objs.length > 0
  }

  /** Viewport-space center of the PLAY AGAIN button (QA/automation hook). */
  get buttonCenter(): { x: number; y: number } {
    return this.lastButtonCenter
  }

  show(score: number, best: number, onRestart: () => void): void {
    this.hide()
    const scene = this.scene
    const vw = scene.scale.width
    const vh = scene.scale.height
    const cx = vw / 2
    const cy = vh / 2 - 30
    const scale = Math.max(0.7, Math.min(1.25, Math.min(vw / 720, vh / 900)))

    // Dim the whole viewport — fades in; game over should not slam to black.
    const dim = scene.add.rectangle(cx, vh / 2, vw, vh, 0x1a1a2e, 0.62).setDepth(60)
    dim.setAlpha(0)
    this.objs.push(dim)
    scene.tweens.add({ targets: dim, alpha: 1, duration: 160, ease: 'Quad.easeOut' })

    // Panel: everything lives in ONE container so the punch-in entrance
    // (0.7 → 1 with Back overshoot, like the discovery popup) scales it all.
    const pw = 440 * scale
    const ph = 420 * scale
    const panel = scene.add.container(cx, cy).setDepth(61)
    this.objs.push(panel)

    const panelG = scene.add.graphics()
    panelG.fillStyle(0xfff8ec, 1)
    panelG.fillRoundedRect(-pw / 2, -ph / 2, pw, ph, 30 * scale)
    panelG.lineStyle(9 * scale, 0x111111, 1)
    panelG.strokeRoundedRect(-pw / 2, -ph / 2, pw, ph, 30 * scale)
    panel.add(panelG)

    panel.add(
      scene.add
        .text(0, -ph * 0.3, 'GAME OVER', {
          fontFamily: FONT_FAMILY,
          fontSize: `${Math.round(56 * scale)}px`,
          color: '#f44336',
          stroke: '#111111',
          strokeThickness: Math.round(7 * scale),
        })
        .setOrigin(0.5),
    )

    const scoreText = scene.add
      .text(0, -ph * 0.08, 'SCORE  0', {
        fontFamily: FONT_FAMILY,
        fontSize: `${Math.round(36 * scale)}px`,
        color: '#00e83b',
        stroke: '#111111',
        strokeThickness: Math.round(5 * scale),
      })
      .setOrigin(0.5)
    panel.add(scoreText)
    panel.add(
      hudText(scene, 0, ph * 0.08, `BEST  ${best}`, scale, {
        color: '#4a4a4a',
        size: 26,
        stroke: 0,
        origin: [0.5, 0.5],
        shadow: false,
      }),
    )

    // Score count-up — the standard suika-genre flourish for the run's payoff.
    const counter = { val: 0 }
    this.countTween = scene.tweens.add({
      targets: counter,
      val: score,
      duration: 550,
      delay: 240,
      ease: 'Cubic.easeOut',
      onUpdate: () => scoreText.setText(`SCORE  ${Math.round(counter.val)}`),
    })

    // PLAY AGAIN — the shared chunky cartoon button, part of the panel.
    const bw = 250 * scale
    const bh = 95 * scale
    const by = cy + ph * 0.32
    this.lastButtonCenter = { x: cx, y: by }
    const btn = new CartoonButton(scene, {
      x: cx,
      y: by,
      w: bw,
      h: bh,
      fill: 0x2d74c9,
      icon: Icons.replay,
      label: 'PLAY AGAIN',
      labelSize: Math.round(26 * scale),
      onPress: onRestart,
    })
    const btnC = btn.containerObj
    if (btnC) {
      panel.add(btnC)
      btnC.setPosition(0, ph * 0.32)
    }

    // Punch-in entrance.
    panel.setScale(0.7)
    scene.tweens.add({ targets: panel, scale: 1, duration: 420, ease: 'Back.easeOut' })
  }

  /** Destroy every object this view created (restart/shutdown). */
  hide(): void {
    this.countTween?.stop()
    this.countTween = null
    for (const o of this.objs) o.destroy()
    this.objs = []
  }
}
