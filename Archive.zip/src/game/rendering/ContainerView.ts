import Phaser from 'phaser'
import { CONTAINER, interiorPolygon, bandQuads, type Vec2 } from '../../config/container'

/**
 * Premium glossy blue arcade frame — ONE continuous U-shaped beam per
 * layer. Every visual layer is a stroke of the same U centerline path
 * (offset outward by its own depth, stroke width = its band width):
 *
 *   ink outline   depth T/2,   width T + 12   (outer silhouette, round cap)
 *   royal body    depth T/2,   width T        (inner edge = physics surface)
 *   cyan strip    depth 7.5%,  width 11%      (inner-edge highlight)
 *   stripe panel  depth 44%,   width 36%      (cream backing, stripes masked)
 *   navy bevel    depth 88.5%, width 17%      (outer-edge shade)
 *
 * TOP ENDS: the ink and body strokes use ROUND caps — each wall terminates
 * in a smooth blue dome (radius T/2) wrapped by the ink outline, i.e. the
 * beam's rounded end, tangent to both straight edges. The inset layers
 * (cyan, stripes, navy) use BUTT caps trimmed back along the wall by a
 * fixed offset, so they terminate in a clean line perpendicular to the
 * wall below the dome — stripes never enter the cap, and the dome above
 * is solid blue. Both walls use the identical construction (the container
 * U is symmetric; offsets are computed from the shared geometry).
 *
 * Everything renders into a cached 720×1280 canvas texture, repainted only
 * when the wall height changes (Raise Walls). Collision geometry, floor
 * position and Raise Walls behavior are untouched — the inner edge of the
 * body stroke IS the physics surface.
 *
 * The COMBO GLOW (light sheet sweeping left → right) is clipped against
 * the band quads — walls and bottom only, never the interior. Chain ≥ 2
 * sweeps in container blue; chain ≥ 4 in rainbow RGB.
 */

type Pt = Vec2

/** Segment P→Q ∩ segment A→B (line intersection; segments overlap by
 * construction in the clipper). */
function segIntersect(P: Pt, Q: Pt, A: Pt, B: Pt): Pt {
  const d1x = Q.x - P.x
  const d1y = Q.y - P.y
  const d2x = B.x - A.x
  const d2y = B.y - A.y
  const denom = d1x * d2y - d1y * d2x
  if (Math.abs(denom) < 1e-9) return { ...P }
  const t = ((A.x - P.x) * d2y - (A.y - P.y) * d2x) / denom
  return { x: P.x + d1x * t, y: P.y + d1y * t }
}

/** Sutherland–Hodgman: clip a convex subject polygon against a quad ring. */
function clipQuad(subject: Pt[], quad: Pt[]): Pt[] {
  const area = quad.reduce(
    (s, p, i) => s + p.x * quad[(i + 1) % quad.length]!.y - quad[(i + 1) % quad.length]!.x * p.y,
    0,
  )
  const positive = area > 0
  let out = subject.slice()
  for (let e = 0; e < 4 && out.length > 0; e++) {
    const A = quad[e]!
    const B = quad[(e + 1) % quad.length]!
    const inside = (p: Pt): boolean => {
      const cr = (B.x - A.x) * (p.y - A.y) - (B.y - A.y) * (p.x - A.x)
      return positive ? cr >= 0 : cr <= 0
    }
    const next: Pt[] = []
    for (let i = 0; i < out.length; i++) {
      const P = out[i]!
      const Q = out[(i + 1) % out.length]!
      const pin = inside(P)
      const qin = inside(Q)
      if (pin) next.push(P)
      if (pin !== qin) next.push(segIntersect(P, Q, A, B))
    }
    out = next
  }
  return out
}

/** Intersection of the infinite lines through segments s1 and s2. */
function lineIntersect(s1: { a: Pt; b: Pt }, s2: { a: Pt; b: Pt }): Pt {
  const d1x = s1.b.x - s1.a.x
  const d1y = s1.b.y - s1.a.y
  const d2x = s2.b.x - s2.a.x
  const d2y = s2.b.y - s2.a.y
  const denom = d1x * d2y - d1y * d2x
  if (Math.abs(denom) < 1e-9) return { ...s1.b }
  const t = ((s2.a.x - s1.a.x) * d2y - (s2.a.y - s1.a.y) * d2x) / denom
  return { x: s1.a.x + d1x * t, y: s1.a.y + d1y * t }
}

/** The three edges of the container U (open top): left wall, floor, right
 * wall. `inner` is the interior polygon [tl, tr, br, bl]. */
function uEdges(inner: Pt[]): Array<{ a: Pt; b: Pt }> {
  return [
    { a: inner[0]!, b: inner[3]! }, // left wall (top → bottom)
    { a: inner[3]!, b: inner[2]! }, // floor (left → right)
    { a: inner[2]!, b: inner[1]! }, // right wall (bottom → top)
  ]
}

/** Each U edge offset OUTWARD by `dist` (outward normal = (-dy, dx)). */
function offsetSegs(inner: Pt[], dist: number): Array<{ a: Pt; b: Pt }> {
  return uEdges(inner).map(({ a, b }) => {
    const dx = b.x - a.x
    const dy = b.y - a.y
    const len = Math.hypot(dx, dy) || 1
    const nx = (-dy / len) * dist
    const ny = (dx / len) * dist
    return { a: { x: a.x + nx, y: a.y + ny }, b: { x: b.x + nx, y: b.y + ny } }
  })
}

/**
 * The stroked U centerline as ONE Path2D: rounded bottom corners (`arcTo`
 * fillets), butt-capped so the layer terminates flush ON the wall-top
 * line. `trim` pulls both wall-top endpoints back down along their wall
 * direction (used by inset layers so they end below the body's dome).
 * `dist` offsets the path outward from the physics polygon; `fillet`
 * scales with the offset so nested strokes stay concentric.
 */
function uPath(inner: Pt[], dist: number, fillet: number, trim = 0): Path2D {
  // ALL three segments offset outward by `dist` — the whole centerline is
  // parallel to the physics polygon, so strokes stay concentric and the
  // floor band lands BELOW the floor line (never inside the interior).
  const [wall, floorSeg, wallR] = offsetSegs(inner, dist) as [
    { a: Pt; b: Pt },
    { a: Pt; b: Pt },
    { a: Pt; b: Pt },
  ]
  const mBL = lineIntersect(wall, floorSeg)
  const mBR = lineIntersect(floorSeg, wallR)
  const shift = (p: Pt, from: Pt, to: Pt): Pt => {
    if (trim === 0) return p
    const ux = (to.x - from.x) / (Math.hypot(to.x - from.x, to.y - from.y) || 1)
    const uy = (to.y - from.y) / (Math.hypot(to.x - from.x, to.y - from.y) || 1)
    return { x: p.x + ux * trim, y: p.y + uy * trim }
  }
  const start = shift(wall.a!, wall.a!, wall.b!)
  const end = shift(wallR.b!, wallR.b!, wallR.a!)
  const p = new Path2D()
  p.moveTo(start.x, start.y)
  p.arcTo(mBL!.x, mBL!.y, floorSeg.b!.x, floorSeg.b!.y, fillet)
  p.arcTo(mBR!.x, mBR!.y, wallR.b!.x, wallR.b!.y, fillet)
  p.lineTo(end.x, end.y)
  return p
}

export class ContainerView {
  private readonly frameImage: Phaser.GameObjects.Image
  private readonly glowG: Phaser.GameObjects.Graphics
  private lastHeight = -1
  /** Band quads (config order) — used ONLY for the combo-glow clipping. */
  private bands: Pt[][] = []
  /** Floor outer edge (for the underside shadow). */
  private floorOuter: { a: Pt; b: Pt } | null = null
  /** Interior corners at the current height: [tl, tr, br, bl]. */
  private corners: Pt[] | null = null
  /** Combo glow sweep: elapsed ms, < 0 = inactive. */
  private glowT = -1
  private readonly glowDuration = 750
  private glowRainbow = false

  constructor(scene: Phaser.Scene) {
    // Canvas texture: 720x1280 stage units, 1:1 — crisp at any zoom, and
    // repainted only when the wall height changes (never per frame).
    if (!scene.textures.exists('container-frame')) {
      scene.textures.addCanvas('container-frame', document.createElement('canvas'))
    }
    this.frameImage = scene.add
      .image(0, 0, 'container-frame')
      .setOrigin(0, 0)
      .setDisplaySize(720, 1280)
      .setDepth(20)
    // Additive light sheet — above the frame, below the balls' scene.
    this.glowG = scene.add.graphics().setDepth(21).setBlendMode(Phaser.BlendModes.ADD)
    this.redrawWalls(CONTAINER.height)
  }

  /** Redraw the whole frame texture at the given wall height (Raise Walls
   * keeps colliders and visuals in lockstep — only wall tops move). */
  redrawWalls(height: number): void {
    if (height === this.lastHeight) return
    this.lastHeight = height
    const T = CONTAINER.visual.bandThickness
    const inner = interiorPolygon(height) as Pt[]
    this.corners = inner
    this.bands = bandQuads(height) as Pt[][]
    // Shadow anchor: just below the ink outline's outer edge (ink reaches
    // depth T/2 + (T+12)/2 = T+6) so it never hides under the frame.
    this.floorOuter = offsetSegs(inner, T + 8)[1]!

    const canvas = (this.frameImage.texture.getSourceImage() as HTMLCanvasElement) ?? null
    if (!canvas) return
    canvas.width = 720
    canvas.height = 1280
    const ctx = canvas.getContext('2d')!
    ctx.clearRect(0, 0, 720, 1280)

    // Stroke layers on the concentric U paths (see uPath). Ink and body
    // use ROUND caps (the wall's rounded blue dome end); inset layers use
    // trimmed butt caps (clean perpendicular stop below the dome).
    const R = T * 0.7
    const TRIM = T * 0.22
    const strokeU = (
      dist: number,
      width: number,
      color: string,
      cap: CanvasLineCap = 'round',
      trim = 0,
    ): void => {
      ctx.strokeStyle = color
      ctx.lineWidth = width
      ctx.lineJoin = 'round'
      ctx.lineCap = cap
      ctx.stroke(uPath(inner, dist, R - T / 2 + dist, trim))
    }

    // 1. Bold black outline: ink stroke 6px wider than the body — its
    //    round cap wraps the whole rounded tip (one continuous silhouette).
    strokeU(T / 2, T + 12, '#111111')
    // 2. Royal-blue body — inner edge lands exactly on the physics polygon;
    //    its round cap is the visible blue rounded end.
    strokeU(T / 2, T, '#3b8df2')
    // 3. Bright cyan strip along the inner (physics) edge: depths 2–13%,
    //    terminating flush below the dome.
    strokeU(T * 0.075, T * 0.11, '#7ee5ff', 'butt', TRIM)
    // 4. Inset hazard-stripe panel: depths 26–62%, drawn on an offscreen
    //    canvas (cream stroke + stripes masked with source-atop), then
    //    blitted. The panel is trimmed back by its cap radius, so stripes
    //    stop in a clean perpendicular line before the dome; the blue dome
    //    above closes the end.
    const PANEL_D = T * 0.44
    const PANEL_W = T * 0.36
    strokeU(PANEL_D, PANEL_W, '#f4ead0', 'butt', PANEL_W / 2)
    const off = document.createElement('canvas')
    off.width = 720
    off.height = 1280
    const octx = off.getContext('2d')!
    octx.strokeStyle = '#f4ead0'
    octx.lineWidth = PANEL_W
    octx.lineJoin = 'round'
    octx.lineCap = 'butt'
    octx.stroke(uPath(inner, PANEL_D, R - T / 2 + PANEL_D, PANEL_W / 2))
    octx.globalCompositeOperation = 'source-atop'
    this.paintStripes(octx)
    ctx.drawImage(off, 0, 0)
    // 5. Restrained dark shaded edge along the outer boundary: 80–97%,
    //    also terminating flush below the dome.
    strokeU(T * 0.885, T * 0.17, '#1e4fa8', 'butt', TRIM)
    // 6. Soft shadow under the floor's outer edge.
    this.paintUnderShadow(ctx)
    // 7. Glossy reflections on the wall bodies.
    this.paintGloss(ctx)
    ;(this.frameImage.texture as Phaser.Textures.CanvasTexture).update()
  }

  /**
   * World-space diagonal hazard stripes (45° in stage coordinates), drawn
   * full-canvas and masked by the caller (source-atop on the panel stroke).
   * One treatment across walls and floor. Stripe edges carry a subtle
   * deterministic micro-jitter (hand-drawn, not shaky).
   */
  private paintStripes(ctx: CanvasRenderingContext2D): void {
    const dx = Math.SQRT1_2
    const dy = Math.SQRT1_2
    const nx = Math.SQRT1_2
    const ny = -Math.SQRT1_2
    const spacing = 26
    const minP = -720 - spacing
    const maxP = 2000 + spacing
    const big = 720 + 1280 // any stripe fully crosses the stage
    let i = 0
    for (let p0 = minP; p0 < maxP; p0 += spacing, i++) {
      const isBlack = i % 2 === 0
      const half = spacing / 2 - 1 // 2px cream gap between stripe bodies
      const j = Math.sin(p0 * 0.83) * 0.6 // deterministic edge micro-jitter
      const cx = nx * p0
      const cy = ny * p0
      const stripe: Pt[] = [
        { x: cx - dx * big - nx * (half + j), y: cy - dy * big - ny * (half + j) },
        { x: cx + dx * big - nx * (half - j), y: cy + dy * big - ny * (half - j) },
        { x: cx + dx * big + nx * (half + j), y: cy + dy * big + ny * (half + j) },
        { x: cx - dx * big + nx * (half - j), y: cy - dy * big + ny * (half - j) },
      ]
      ctx.fillStyle = isBlack ? '#161616' : '#fcf4d5'
      const path = new Path2D()
      path.moveTo(stripe[0]!.x, stripe[0]!.y)
      for (let k = 1; k < 4; k++) path.lineTo(stripe[k]!.x, stripe[k]!.y)
      path.closePath()
      ctx.fill(path)
    }
  }

  /** Soft dark-blue shadow below the floor's outer edge — one smooth
   * gradient fade. Inset at the sides so it never pokes past the rounded
   * corners. */
  private paintUnderShadow(ctx: CanvasRenderingContext2D): void {
    const { a, b } = this.floorOuter ?? { a: null, b: null }
    if (!a || !b) return
    const inset = 22
    const h = 20
    const grad = ctx.createLinearGradient(0, a.y, 0, a.y + h)
    grad.addColorStop(0, 'rgba(21, 42, 90, 0.30)')
    grad.addColorStop(1, 'rgba(21, 42, 90, 0)')
    const path = new Path2D()
    path.moveTo(a.x + inset, a.y)
    path.lineTo(b.x - inset, b.y)
    path.lineTo(b.x - inset, b.y + h)
    path.lineTo(a.x + inset, a.y + h)
    path.closePath()
    ctx.fillStyle = grad
    ctx.fill(path)
  }

  /** Restrained glossy reflections on the wall bodies: two soft white
   * streaks per wall, anchored to the wall TOP regardless of run direction. */
  private paintGloss(ctx: CanvasRenderingContext2D): void {
    const inner = this.corners
    if (!inner) return
    const walls: Array<{ top: Pt; bottom: Pt }> = [
      { top: inner[0]!, bottom: inner[3]! }, // left wall
      { top: inner[1]!, bottom: inner[2]! }, // right wall
    ]
    const T = CONTAINER.visual.bandThickness
    // Interior centroid: the gloss normal must always point OUTWARD (into
    // the band), regardless of the wall's run direction.
    const cx = inner.reduce((s, p) => s + p.x, 0) / 4
    const cy = inner.reduce((s, p) => s + p.y, 0) / 4
    for (const { top, bottom } of walls) {
      const dx = bottom.x - top.x
      const dy = bottom.y - top.y
      const len = Math.hypot(dx, dy) || 1
      let nx = -dy / len
      let ny = dx / len
      const mx = (top.x + bottom.x) / 2 - cx
      const my = (top.y + bottom.y) / 2 - cy
      if (nx * mx + ny * my < 0) {
        nx = -nx
        ny = -ny
      }
      const streak = (s0: number, s1: number, d0: number, d1: number, alpha: number): void => {
        const pts: Pt[] = [
          { x: top.x + dx * s0 + nx * d0, y: top.y + dy * s0 + ny * d0 },
          { x: top.x + dx * s1 + nx * d0, y: top.y + dy * s1 + ny * d0 },
          { x: top.x + dx * s1 + nx * d1, y: top.y + dy * s1 + ny * d1 },
          { x: top.x + dx * s0 + nx * d1, y: top.y + dy * s0 + ny * d1 },
        ]
        const path = new Path2D()
        path.moveTo(pts[0]!.x, pts[0]!.y)
        for (let k = 1; k < 4; k++) path.lineTo(pts[k]!.x, pts[k]!.y)
        path.closePath()
        ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`
        ctx.fill(path)
      }
      streak(0.06, 0.3, T * 0.12, T * 0.24, 0.2)
      streak(0.38, 0.46, T * 0.12, T * 0.24, 0.13)
    }
  }

  /** Trigger the combo glow: blue sweep for combos, rainbow RGB for big
   * ones (chain depth ≥ 4). Restarts cleanly if a sweep is already running. */
  playGlow(chainDepth: number): void {
    this.glowRainbow = chainDepth >= 4
    this.glowT = 0
  }

  /** Per-frame glow sweep (called from PlaygroundScene.update). The light
   * sheet is clipped to the bands — walls and bottom only, never the
   * interior. */
  update(delta: number): void {
    if (this.glowT < 0) return
    this.glowT += delta
    const g = this.glowG
    g.clear()
    const t = this.glowT / this.glowDuration
    if (t >= 1) {
      this.glowT = -1
      return
    }
    if (this.bands.length === 0) return
    let minX = Infinity
    let maxX = -Infinity
    let minY = Infinity
    let maxY = -Infinity
    for (const band of this.bands) {
      for (const p of band) {
        minX = Math.min(minX, p.x)
        maxX = Math.max(maxX, p.x)
        minY = Math.min(minY, p.y)
        maxY = Math.max(maxY, p.y)
      }
    }
    const barW = (maxX - minX) * 0.5
    const x = minX - barW + (maxX - minX + 2 * barW) * t
    const envelope = t < 0.15 ? t / 0.15 : t > 0.8 ? (1 - t) / 0.2 : 1
    const slices = 12
    for (let i = 0; i < slices; i++) {
      const sx = x + (i / slices) * barW
      const sw = barW / slices + 1
      const fall = 1 - Math.abs((i + 0.5) / slices - 0.5) * 2
      const hue = this.glowRainbow ? (this.glowT * 0.0004 + i / slices) % 1 : null
      const color = hue == null
        ? (i < slices / 2 ? 0x59c1ff : 0xbfe4ff)
        : (Phaser.Display.Color.HSVToRGB(hue, 0.85, 1).color as number)
      const alpha = 0.18 * fall * envelope
      const bar: Pt[] = [
        { x: sx, y: minY },
        { x: sx + sw, y: minY },
        { x: sx + sw, y: maxY },
        { x: sx, y: maxY },
      ]
      for (const band of this.bands) {
        const lit = clipQuad(bar, band)
        if (lit.length >= 3) {
          g.fillStyle(color, alpha)
          g.fillPoints(lit.map((p) => new Phaser.Math.Vector2(p.x, p.y)), true)
        }
      }
    }
    const coreW = barW * 0.3
    const cx = x + barW * 0.7
    const core: Pt[] = [
      { x: cx, y: minY },
      { x: cx + coreW, y: minY },
      { x: cx + coreW, y: maxY },
      { x: cx, y: maxY },
    ]
    for (const band of this.bands) {
      const lit = clipQuad(core, band)
      if (lit.length >= 3) {
        g.fillStyle(0xffffff, 0.2 * envelope)
        g.fillPoints(lit.map((p) => new Phaser.Math.Vector2(p.x, p.y)), true)
      }
    }
  }
}
