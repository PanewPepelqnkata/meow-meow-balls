// p2202: verify the RESTORED container rendering.
// 1. U continuity: frame opaque along wall+floor centerlines (walls meet floor).
// 2. Stripes present on ALL THREE sections (black + cream in the panel band).
// 3. Layer alignment: cyan near inner edge, navy near outer edge.
// 4. Nothing floats outside the frame (transparent at depth ≥ 86).
// 5. Full-page screenshot saved for human review.
import { chromium } from 'playwright'
import fs from 'node:fs'

const wait = (ms) => new Promise((r) => setTimeout(r, ms))

// Mirror config/container.ts geometry (normal height).
const topWidth = 495.905, bottomWidth = 405, height = 320, topY = 765
const floorY = topY + height
const slopePerY = (topWidth - bottomWidth) / 2 / height
const topHalf = bottomWidth / 2 + slopePerY * height
const inner = [
  { x: 360 - topHalf, y: floorY - height }, // tl
  { x: 360 + topHalf, y: floorY - height }, // tr
  { x: 360 + bottomWidth / 2, y: floorY },  // br
  { x: 360 - bottomWidth / 2, y: floorY },  // bl
]
// Open-top U edges: left wall tl→bl, floor bl→br, right wall br→tr
const edges = [
  { a: inner[0], b: inner[3], name: 'left' },
  { a: inner[3], b: inner[2], name: 'floor' },
  { a: inner[2], b: inner[1], name: 'right' },
]
const T = 74

const b = await chromium.launch()
const p = await b.newPage({ viewport: { width: 1648, height: 936 } })
const errs = []
p.on('pageerror', (e) => errs.push(e.message))
await p.goto('http://localhost:5179', { waitUntil: 'networkidle' })
await p.waitForFunction(() => window.__brCreateDone === 'yes', { timeout: 20000 })
const play = (await p.evaluate(() => window.__brMenu.buttons())).find((x) => x.label === 'PLAY')
await p.mouse.click(play.x + play.w / 2, play.y + play.h / 2)
await wait(1500)
fs.mkdirSync('qa/screens/p2202-smoke', { recursive: true })
fs.writeFileSync('qa/screens/p2202-smoke/full.png', await p.screenshot())

const report = await p.evaluate(({ edges, T }) => {
  const tex = window.__brGame.textures.get('container-frame').getSourceImage()
  const c = document.createElement('canvas')
  c.width = tex.width; c.height = tex.height
  const ctx = c.getContext('2d')
  ctx.drawImage(tex, 0, 0)
  const img = ctx.getImageData(0, 0, tex.width, tex.height)
  const px = (x, y) => {
    x = Math.round(x); y = Math.round(y)
    if (x < 0 || y < 0 || x >= tex.width || y >= tex.height) return [0, 0, 0, 0]
    const i = (y * tex.width + x) * 4
    return [img.data[i], img.data[i + 1], img.data[i + 2], img.data[i + 3]]
  }
  const near = (rgb, ref, tol) => rgb.length === 4 && rgb[3] > 150 &&
    Math.abs(rgb[0] - ref[0]) < tol && Math.abs(rgb[1] - ref[1]) < tol && Math.abs(rgb[2] - ref[2]) < tol
  const out = {}
  for (const { a, b, name } of edges) {
    const dx = b.x - a.x, dy = b.y - a.y
    const len = Math.hypot(dx, dy)
    const nx = -dy / len, ny = dx / len // outward normal
    const at = (s, d) => px(a.x + dx * s + nx * d, a.y + dy * s + ny * d)
    // 1. Continuity at body center depth (skip 8% ends = corner arcs)
    let gaps = 0
    for (let s = 0.08; s <= 0.92; s += 0.01) {
      if (at(s, T / 2)[3] < 200) gaps++
    }
    // 2. Stripes in panel band (depth 32), sample s 0.15..0.85
    let black = 0, cream = 0, n = 0
    for (let s = 0.15; s <= 0.85; s += 0.004) {
      n++
      const rgb = at(s, 32)
      if (near(rgb, [22, 22, 22], 26)) black++
      else if (near(rgb, [252, 244, 213], 26)) cream++
    }
    // 3. Alignment: cyan at 5.5, body at 14 (between cyan and panel),
    //    navy at 65
    let cyan = 0, navy = 0, body = 0, cn = 0
    for (let s = 0.15; s <= 0.85; s += 0.004) {
      cn++
      if (near(at(s, 5.5), [126, 229, 255], 40)) cyan++
      if (near(at(s, 65), [30, 79, 168], 40)) navy++
      if (near(at(s, 14), [59, 141, 242], 40)) body++
    }
    // 4. Exterior: no FRAME-COLORED pixels at depth ≥ 86 (the designed
    //    soft shadow under the floor is rgba(21,42,90) — not flagged).
    let out86 = 0, out104 = 0
    for (let s = 0.1; s <= 0.9; s += 0.005) {
      for (const [d, slot] of [[86, 0], [104, 1]]) {
        const rgb = at(s, d)
        const frameColored = near(rgb, [59, 141, 242], 45) || near(rgb, [126, 229, 255], 45) ||
          near(rgb, [30, 79, 168], 45) || near(rgb, [252, 244, 213], 30) ||
          (rgb[3] > 150 && rgb[0] < 60 && rgb[1] < 60 && rgb[2] < 60)
        if (frameColored) { if (slot === 0) out86++; else out104++ }
      }
    }
    out[name] = {
      continuityGaps: gaps,
      stripes: { blackPct: Math.round((black / n) * 100), creamPct: Math.round((cream / n) * 100) },
      layers: { bodyPct: Math.round((body / cn) * 100), cyanPct: Math.round((cyan / cn) * 100), navyPct: Math.round((navy / cn) * 100) },
      exterior: { d86: out86, d104: out104 },
      interiorSpill: (() => {
        // Just INSIDE the inner edge (depth -10): must be transparent,
        // except the wall-top dome region (s < 0.16 on walls).
        let spill = 0, m = 0
        const sLo = name === 'floor' ? 0.1 : 0.2
        for (let s = sLo; s <= 0.9; s += 0.005) {
          m++
          if (at(s, -10)[3] > 10) spill++
        }
        return `${spill}/${m}`
      })(),
      cornerJunction: (() => {
        // Continuity through the bottom corner arcs: sample depth 37 at
        // s 0.97..1.0 (wall side) and 0.0..0.03 (floor side).
        let miss = 0, m = 0
        for (const s of [0.97, 0.975, 0.98, 0.985, 0.99, 0.995, 0.01, 0.015, 0.02, 0.025, 0.03]) {
          m++
          if (at(s, T / 2)[3] < 200) miss++
        }
        void m
        return miss
      })(),
    }
  }
  // Junction continuity: the two bottom corners (floor ends) — opaque at
  // depth 37 along the fillet arc between wall and floor.
  const cornerOk = (corner, dirIn, dirOut) => {
    // sample a quarter arc of radius ~37 centered near the offset corner
    let miss = 0
    for (let a = 0; a <= Math.PI / 2; a += Math.PI / 20) {
      const d = dirIn.map((v, k) => v * Math.cos(a) + dirOut[k] * Math.sin(a))
      const rgb = px(corner.x + d[0] * 37 + dirIn[0] * 0, corner.y + d[1] * 37)
      void rgb
    }
    return miss
  }
  void cornerOk
  return out
}, { edges, T })

console.log(JSON.stringify(report, null, 1))
console.log('pageerrors:', JSON.stringify(errs))
await p.close(); await b.close()
