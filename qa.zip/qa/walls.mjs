/* global window, console, process */
import { chromium } from 'playwright'
import { mkdirSync, writeFileSync } from 'node:fs'
const BASE = process.argv[2] ?? 'http://localhost:5174/'
mkdirSync('qa/screens', { recursive: true })
const browser = await chromium.launch()
const page = await browser.newPage({ viewport: { width: 720, height: 1280 } })
page.on('pageerror', (e) => console.log('PAGEERROR', e.message, '\n', e.stack))
await page.goto(BASE, { waitUntil: 'networkidle' })
await page.waitForFunction(() => window.__brCreateDone === 'yes', null, { timeout: 20000 })
// a couple of balls first
for (const x of [300, 420]) {
  await page.evaluate((x) => window.__brScene.dropAt(x), x)
  await page.waitForTimeout(600)
}
await page.waitForTimeout(2500)
const before = await page.screenshot({ path: 'qa/screens/e0-walls-normal.png', type: 'png' })
// Raise Walls badge: canvas-drawn at (w-136, 84) in stage coords (1:1 viewport)
await page.mouse.click(216, 1236)
await page.waitForTimeout(1300)
await page.screenshot({ path: 'qa/screens/e1-walls-raised.png', type: 'png' })
await page.waitForTimeout(1500)
const after = await page.screenshot({ type: 'png' })
// wall animation must not launch particles or leave them outside
const state = await page.evaluate(() => window.__brState ?? null)
console.log('WALLS TEST DONE; state:', JSON.stringify(state?.areas ?? null))
void before; void after
writeFileSync('qa/walls-report.json', JSON.stringify({ clicked: true, state }, null, 2))
await browser.close()
