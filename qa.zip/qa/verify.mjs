/* global window, console, process */
/* Browser verification for the soft-body stabilization work.
 * Runs the NORMAL production game (dev server, no query params) and drives
 * the same scenarios as the headless diagnostics, capturing screenshots and
 * live state. Usage: node qa/verify.mjs [baseUrl]
 */
import { chromium } from 'playwright'
import { mkdirSync, writeFileSync } from 'node:fs'

const BASE = process.argv[2] ?? 'http://localhost:5173/'
const OUT = 'qa/screens'
mkdirSync(OUT, { recursive: true })

const browser = await chromium.launch()
const page = await browser.newPage({ viewport: { width: 720, height: 1280 } })
page.on('pageerror', (e) => console.log('PAGEERROR', e.message))
page.on('console', (m) => {
  if (m.type() === 'error') console.log('CONSOLEERROR', m.text())
})

await page.goto(BASE, { waitUntil: 'networkidle' })
await page.waitForFunction(() => window.__brCreateDone === 'yes', null, { timeout: 20000 })
await page.waitForTimeout(500)

const state = () => page.evaluate(() => window.__brState ?? null)
const drop = (x) => page.evaluate((x) => window.__brScene.dropAt(x), x)
const counts = () => page.evaluate(() => window.__brScene.physicsCounts())

const report = { scenarios: [] }

// --- Scenario A: single drop — controlled impact, normal fall ---
await drop(360)
await page.waitForTimeout(700)
await page.screenshot({ path: `${OUT}/a1-impact.png` })
await page.waitForTimeout(2500)
await page.screenshot({ path: `${OUT}/a2-settled.png` })
report.scenarios.push({ name: 'A single drop', state: await state() })

// --- Scenario B: small ball between two larger ---
// two tier-3 (pink) side by side, then a tier-1 into the gap: approximate by
// dropping several balls to build a pile, then small ones into gaps
await drop(250)
await page.waitForTimeout(400)
await drop(470)
await page.waitForTimeout(400)
await drop(360)
await page.waitForTimeout(1500)
await page.screenshot({ path: `${OUT}/b1-gap-build.png` })
await drop(360)
await page.waitForTimeout(350)
await page.screenshot({ path: `${OUT}/b2-gap-impact.png` })
await page.waitForTimeout(2500)
await page.screenshot({ path: `${OUT}/b3-gap-settled.png` })
report.scenarios.push({ name: 'B gap drops', state: await state() })

// --- Scenario C: rapid drops into the pile ---
for (let i = 0; i < 6; i++) {
  await drop(240 + Math.random() * 240)
  await page.waitForTimeout(180)
}
await page.screenshot({ path: `${OUT}/c1-rapid.png` })
await page.waitForTimeout(3000)
await page.screenshot({ path: `${OUT}/c2-rapid-settled.png` })
report.scenarios.push({ name: 'C rapid drops', state: await state() })

// --- Scenario D: sustained pressure pile + jitter measurement ---
// sample the state 12 times over 4s; report ball count/areas/speeds
const samples = []
for (let i = 0; i < 12; i++) {
  samples.push(await state())
  await page.waitForTimeout(340)
}
report.scenarios.push({ name: 'D settled sampling', samples })

// --- Scenario E: raise walls ability ---
await page.evaluate(() => window.__brScene != null)
// the HUD button lives in the DOM; find the raise-walls control by text
const btn = page.locator('button', { hasText: /wall/i }).first()
if (await btn.count()) {
  await btn.click()
  await page.waitForTimeout(1200)
  await page.screenshot({ path: `${OUT}/e1-walls-raised.png` })
  await page.waitForTimeout(1000)
} else {
  console.log('no wall button found (skipping E screenshot)')
}
report.scenarios.push({ name: 'E raise walls', state: await state(), counts: await counts() })

// --- Scenario F: restart ---
await page.keyboard.press('r')
await page.waitForTimeout(600)
report.scenarios.push({ name: 'F restart', state: await state() })
await page.screenshot({ path: `${OUT}/f1-restart.png` })

writeFileSync('qa/verify-report.json', JSON.stringify(report, null, 2))
console.log('VERIFY DONE')
console.log(JSON.stringify(report.scenarios.map((s) => ({ name: s.name, balls: s.state?.balls, score: s.state?.score })), null, 1))
await browser.close()
